grails.project.dependency.resolution = {
    inherits("global")
    repositories {
        mavenCentral()
	}
    dependencies {
        runtime 'org.jsoup:jsoup:1.6.1'
		runtime 'org.apache.commons:commons-lang3:3.0.1'
		runtime 'org.pegdown:pegdown:1.1.0'
    }
}